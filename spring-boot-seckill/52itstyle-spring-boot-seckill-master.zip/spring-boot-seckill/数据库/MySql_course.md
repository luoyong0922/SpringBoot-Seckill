## 教程

### 文字教程

[MySQL 教程（菜鸟教程）](http://www.runoob.com/mysql/mysql-tutorial.html)

[MySQL教程（易百教程）](https://www.yiibai.com/mysql/)

###  视频教程

[MySQL开发技巧（一）](https://www.imooc.com/learn/398)　　
[MySQL开发技巧（二）](https://www.imooc.com/learn/427)　　
[MySQL开发技巧（三）](https://www.imooc.com/learn/449)

[MySQL5.7版本新特性](https://www.imooc.com/learn/533)　　
[性能优化之MySQL优化](https://www.imooc.com/learn/194)

[MySQL集群（PXC）入门](https://www.imooc.com/learn/993)　　
[MyCAT入门及应用](https://www.imooc.com/learn/951)
